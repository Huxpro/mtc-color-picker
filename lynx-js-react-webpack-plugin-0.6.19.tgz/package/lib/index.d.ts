/**
 * @packageDocumentation
 *
 * A webpack plugin to integrate webpack with ReactLynx.
 */
export { ReactWebpackPlugin } from './ReactWebpackPlugin.js';
export type { ReactWebpackPluginOptions } from './ReactWebpackPlugin.js';
export type { ExtractStrConfig } from '@lynx-js/react/transform';
export { LAYERS } from './layer.js';
export type { ReactLoaderOptions } from './loaders/options.js';
