import type { Compiler } from '@rspack/core';
import type { ExtractStrConfig } from '@lynx-js/react/transform';
import { LAYERS } from './layer.js';
/**
 * The options for ReactWebpackPlugin
 *
 * @public
 */
interface ReactWebpackPluginOptions {
    /**
     * {@inheritdoc @lynx-js/react-rsbuild-plugin#PluginReactLynxOptions.compat.disableCreateSelectorQueryIncompatibleWarning}
     */
    disableCreateSelectorQueryIncompatibleWarning?: boolean | undefined;
    /**
     * {@inheritdoc @lynx-js/react-rsbuild-plugin#PluginReactLynxOptions.firstScreenSyncTiming}
     */
    firstScreenSyncTiming?: 'immediately' | 'jsReady';
    /**
     * {@inheritdoc @lynx-js/react-rsbuild-plugin#PluginReactLynxOptions.enableSSR}
     */
    enableSSR?: boolean;
    /**
     * The chunk names to be considered as main thread chunks.
     */
    mainThreadChunks?: string[] | undefined;
    /**
     * Merge same string literals in JS and Lepus to reduce output bundle size.
     * Set to `false` to disable.
     *
     * @defaultValue false
     */
    extractStr?: Partial<ExtractStrConfig> | boolean;
    /**
     * Whether to enable lazy bundle.
     *
     * @alpha
     */
    experimental_isLazyBundle?: boolean;
    /**
     * Whether to enable profile.
     *
     * @defaultValue `false` when production, `true` when development
     */
    profile?: boolean | undefined;
}
/**
 * ReactWebpackPlugin allows using ReactLynx with webpack
 *
 * @example
 * ```js
 * // webpack.config.js
 * import { ReactWebpackPlugin } from '@lynx-js/react-webpack-plugin'
 * export default {
 *   plugins: [new ReactWebpackPlugin()],
 * }
 * ```
 *
 * @public
 */
declare class ReactWebpackPlugin {
    #private;
    private readonly options?;
    /**
     * The loaders for ReactLynx.
     *
     * @remarks
     * Note that this loader will only transform JSX/TSX to valid JavaScript.
     * For `.tsx` files, the type annotations would not be eliminated.
     * You should use `babel-loader` or `swc-loader` to load TypeScript files.
     *
     * @example
     * ```js
     * // webpack.config.js
     * import { ReactWebpackPlugin, LAYERS } from '@lynx-js/react-webpack-plugin'
     * export default {
     *   module: {
     *     rules: [
     *       {
     *         test: /\.tsx?$/,
     *         layer: LAYERS.MAIN_THREAD,
     *         use: ['swc-loader', ReactWebpackPlugin.loaders.MAIN_THREAD]
     *       },
     *       {
     *         test: /\.tsx?$/,
     *         layer: LAYERS.BACKGROUND,
     *         use: ['swc-loader', ReactWebpackPlugin.loaders.BACKGROUND]
     *       },
     *     ],
     *   },
     *   plugins: [new ReactWebpackPlugin()],
     * }
     * ```
     *
     * @public
     */
    static loaders: Record<keyof typeof LAYERS, string>;
    constructor(options?: ReactWebpackPluginOptions | undefined);
    /**
     * `defaultOptions` is the default options that the {@link ReactWebpackPlugin} uses.
     *
     * @public
     */
    static defaultOptions: Readonly<Required<ReactWebpackPluginOptions>>;
    /**
     * The entry point of a webpack plugin.
     * @param compiler - the webpack compiler
     */
    apply(compiler: Compiler): void;
}
export { ReactWebpackPlugin as ReactWebpackPlugin };
export type { ReactWebpackPluginOptions };
