import { Element } from './api/element.js';
import type { WorkletRef, WorkletRefId, WorkletRefImpl } from './bindings/types.js';
interface RefImpl {
    _workletRefMap: Record<WorkletRefId, WorkletRef<unknown>>;
    _firstScreenWorkletRefMap: Record<WorkletRefId, WorkletRef<unknown>>;
    updateWorkletRef(refImpl: WorkletRefImpl<Element | null>, element: ElementNode | null): void;
    updateWorkletRefInitValueChanges(patch: [number, unknown][]): void;
    clearFirstScreenWorkletRefMap(): void;
}
declare function initWorkletRef(): RefImpl;
declare const createWorkletRef: <T>(id: WorkletRefId, value: T) => WorkletRef<T>;
declare const getFromWorkletRefMap: <T>(refImpl: WorkletRefImpl<T>) => WorkletRef<T>;
declare function removeValueFromWorkletRefMap(id: WorkletRefId): void;
declare function updateWorkletRefInitValueChanges(patch: [WorkletRefId, unknown][]): void;
export { type RefImpl, createWorkletRef, initWorkletRef, getFromWorkletRefMap, removeValueFromWorkletRefMap, updateWorkletRefInitValueChanges, };
