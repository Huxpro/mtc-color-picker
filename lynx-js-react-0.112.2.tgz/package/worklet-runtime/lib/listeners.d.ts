declare function initEventListeners(): void;
export { initEventListeners };
