declare function initWorklet(): void;
export { initWorklet };
