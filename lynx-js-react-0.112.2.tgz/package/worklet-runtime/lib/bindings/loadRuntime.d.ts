import '../global.js';
/**
 * Loads and initializes the Lepus chunk in the main thread.
 * @param __schema - The dynamic component entry for loading the Lepus chunk.
 * @returns A boolean indicating whether the Lepus chunk was loaded and initialized successfully.
 */
declare function loadWorkletRuntime(__schema?: string): boolean;
export { loadWorkletRuntime };
