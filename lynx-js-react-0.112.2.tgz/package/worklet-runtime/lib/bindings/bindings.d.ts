import type { ClosureValueType, Worklet } from './types.js';
/**
 * Executes the worklet ctx.
 * @param worklet - The Worklet ctx to run.
 * @param params - An array as parameters of the worklet run.
 */
declare function runWorkletCtx(worklet: Worklet, params: ClosureValueType[]): unknown;
/**
 * Update the initial value of the `WorkletRef`.
 *
 * @param patch - An array containing the index and new value of the worklet value.
 */
declare function updateWorkletRefInitValueChanges(patch?: [number, unknown][]): void;
export { runWorkletCtx, updateWorkletRef, updateWorkletRefInitValueChanges, registerWorklet, delayRunOnBackground };
