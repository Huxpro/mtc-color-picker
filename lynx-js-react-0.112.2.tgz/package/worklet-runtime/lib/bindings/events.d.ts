import type { Worklet } from './types.js';
declare const enum WorkletEvents {
    runWorkletCtx = "Lynx.Worklet.runWorkletCtx",
    runOnBackground = "Lynx.Worklet.runOnBackground",
    FunctionCallRet = "Lynx.Worklet.FunctionCallRet",
    releaseBackgroundWorkletCtx = "Lynx.Worklet.releaseBackgroundWorkletCtx",
    releaseWorkletRef = "Lynx.Worklet.releaseWorkletRef"
}
interface RunWorkletCtxData {
    resolveId: number;
    worklet: Worklet;
    params: unknown[];
}
interface RunWorkletCtxRetData {
    resolveId: number;
    returnValue: unknown;
}
interface ReleaseWorkletRefData {
    id: number;
}
export { WorkletEvents, type RunWorkletCtxData, type RunWorkletCtxRetData, type ReleaseWorkletRefData };
