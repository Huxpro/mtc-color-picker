export interface EomImpl {
    setShouldFlush(value: boolean): void;
}
export declare function initEomImpl(): EomImpl;
