export declare class Element {
    private static willFlush;
    private readonly element;
    constructor(element: ElementNode);
    setAttribute(name: string, value: unknown): void;
    setStyleProperty(name: string, value: string): void;
    setStyleProperties(styles: Record<string, string>): void;
    getAttribute(attributeName: string): unknown;
    getAttributeNames(): string[];
    querySelector(selector: string): Element | null;
    querySelectorAll(selector: string): Element[];
    invoke(methodName: string, params?: Record<string, unknown>): Promise<unknown>;
    private flushElementTree;
}
