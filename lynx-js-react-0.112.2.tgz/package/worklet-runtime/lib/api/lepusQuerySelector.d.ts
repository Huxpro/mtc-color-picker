import { Element } from './element.js';
export declare function querySelector(cssSelector: string): Element | null;
export declare function querySelectorAll(cssSelector: string): Element[];
