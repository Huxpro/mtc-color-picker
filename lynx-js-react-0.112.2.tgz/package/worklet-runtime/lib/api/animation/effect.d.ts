import type { Element } from '../element.js';
export declare class KeyframeEffect {
    readonly target: Element;
    readonly keyframes: Record<string, number | string>[];
    readonly options: Record<string, number | string>;
    constructor(target: Element, keyframes: Record<string, number | string>[], options: Record<string, number | string>);
}
