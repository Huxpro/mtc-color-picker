import type { KeyframeEffect } from './effect.js';
export declare enum AnimationOperation {
    START = 0,// Start a new animation
    PLAY = 1,// Play/resume a paused animation
    PAUSE = 2,// Pause an existing animation
    CANCEL = 3
}
export declare class Animation {
    static count: number;
    readonly effect: KeyframeEffect;
    readonly id: string;
    constructor(effect: KeyframeEffect);
    cancel(): void;
    pause(): void;
    play(): void;
    private start;
}
