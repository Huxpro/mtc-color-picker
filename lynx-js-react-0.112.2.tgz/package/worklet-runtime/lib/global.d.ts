import type { ClosureValueType, Worklet } from './bindings/types.js';
import type { RunOnBackgroundDelayImpl } from './delayRunOnBackground.js';
import type { EventDelayImpl } from './delayWorkletEvent.js';
import type { JsFunctionLifecycleManager } from './jsFunctionLifecycle.js';
import type { RefImpl } from './workletRef.js';
declare global {
    var lynxWorkletImpl: {
        _workletMap: Record<string, (...args: unknown[]) => unknown>;
        _jsFunctionLifecycleManager?: JsFunctionLifecycleManager;
        _eventDelayImpl: EventDelayImpl;
        _refImpl: RefImpl;
        _runOnBackgroundDelayImpl: RunOnBackgroundDelayImpl;
        _hydrateCtx: (worklet: Worklet, firstScreenWorklet: Worklet) => void;
    };
    function runWorklet(ctx: Worklet, params: ClosureValueType[]): unknown;
    function registerWorklet(type: string, id: string, worklet: (...args: unknown[]) => unknown): void;
    function registerWorkletInternal(type: string, id: string, worklet: (...args: unknown[]) => unknown): void;
}
