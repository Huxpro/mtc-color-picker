import type { ClosureValueType, EventCtx, RunWorkletOptions } from './bindings/types.js';
export declare const EventResult: {
    readonly kDefault: 0;
    readonly kStopPropagationMask: 1;
    readonly kStopImmediatePropagationMask: 2;
};
type EventLike = Record<string, ClosureValueType>;
export declare function isEventObject(ctx: ClosureValueType[], options?: RunWorkletOptions): ctx is [EventLike, ...ClosureValueType[]];
/**
 * Add event methods to an event object if needed
 * @param ctx The event object to enhance
 * @param options The run worklet options
 * @returns A tuple of boolean and the event return result
 */
export declare function addEventMethodsIfNeeded(ctx: ClosureValueType[], options?: RunWorkletOptions): [boolean, EventCtx];
export {};
