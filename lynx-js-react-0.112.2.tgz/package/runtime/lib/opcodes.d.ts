import { SnapshotInstance } from './snapshot.js';
interface SSRFiberElement {
    ssrID: string;
}
export type SSRSnapshotInstance = [string, number, SSRFiberElement[]];
export declare function ssrHydrateByOpcodes(opcodes: any[], into: SnapshotInstance, refMap?: Record<string, FiberElement>): void;
export declare function renderOpcodesInto(opcodes: any[], into: SnapshotInstance, refs: any[]): void;
export {};
