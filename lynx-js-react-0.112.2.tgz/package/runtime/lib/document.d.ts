import { BackgroundSnapshotInstance } from './backgroundSnapshot.js';
import { SnapshotInstance } from './snapshot.js';
/**
 * This module implements an Interface Adapter Pattern to integrate Preact's
 * rendering system with Lynx's custom Snapshot-based virtual DOM.
 *
 * It works by:
 * 1. Defining a minimal {@link Document}-like interface that Preact expects
 * 2. Implementing this interface to return our {@link Snapshot} instances
 * 3. Maintaining the same method signatures as the standard DOM API
 *
 * This allows Preact to build its virtual tree using our Snapshot system
 * without knowing it's not working with a real DOM.
 */
/**
 * Defines the minimal document interface that Preact expects, depending on
 * which thread is running.
 */
interface SnapshotDocumentAdapter {
    createElement(type: string): BackgroundSnapshotInstance | SnapshotInstance;
    createElementNS(ns: string | null, type: string): BackgroundSnapshotInstance | SnapshotInstance;
    createTextNode(text: string): BackgroundSnapshotInstance | SnapshotInstance;
}
declare const document: SnapshotDocumentAdapter;
/**
 * Sets up the document interface for the background thread.
 * All DOM operations are intercepted to create {@link BackgroundSnapshotInstance}.
 */
declare function setupBackgroundDocument(): void;
/**
 * Sets up the document interface for the main thread.
 * All DOM operations are intercepted to create {@link SnapshotInstance}.
 */
declare function setupDocument(): void;
export { document, setupBackgroundDocument, setupDocument };
