import { BackgroundSnapshotInstance } from './backgroundSnapshot.js';
import { SnapshotInstance } from './snapshot.js';
/**
 * The internal ReactLynx's root.
 * {@link @lynx-js/react!Root | root}.
 */
declare let __root: (SnapshotInstance | BackgroundSnapshotInstance) & {
    __jsx?: React.ReactNode;
    __opcodes?: any[];
    /**
     * Returns the type of node.
     *
     * [MDN Reference](https://developer.mozilla.org/docs/Web/API/Node/nodeType)
     */
    nodeType?: Element['nodeType'];
};
declare function setRoot(root: typeof __root): void;
export { __root, setRoot };
