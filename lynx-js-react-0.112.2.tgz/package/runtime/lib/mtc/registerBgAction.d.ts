export declare const gBgActions: Map<number, Function>;
export declare function registerBgAction(action: Function): number;
