import type { FunctionalComponent } from 'preact';
export declare const mtcComponentTypes: Map<string, FunctionalComponent>;
export declare function registerMTC(id: string, MTC: FunctionalComponent): FunctionalComponent;
