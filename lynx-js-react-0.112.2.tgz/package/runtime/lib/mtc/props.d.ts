export declare function transformMTCProps(props: unknown): void;
