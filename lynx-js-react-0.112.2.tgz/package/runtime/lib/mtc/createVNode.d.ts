import type { Attributes, VNode } from 'preact';
import { SnapshotInstance } from '../snapshot.js';
export declare function createElementVNode(type: string, props: Attributes & {
    'mtc:ref'?: (si: SnapshotInstance) => void;
}): VNode;
