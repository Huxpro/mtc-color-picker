export declare function genMTCInstanceId(): number;
