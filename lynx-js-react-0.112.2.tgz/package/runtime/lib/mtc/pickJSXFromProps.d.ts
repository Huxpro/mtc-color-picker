import type { VNode } from 'preact';
declare const MTC_TYPE: "__MTC_SLOT__";
type MTCFactory = (...args: any[]) => MTCPlaceholder;
interface MTCPlaceholder {
    $$typeof: typeof MTC_TYPE;
    i: number;
}
type MTCPayload = Record<string, MTCPlaceholder | MTCFactory>;
export declare function pickJSXFromProps(props?: Record<string, any>): [[VNode, any][], MTCPayload];
export {};
