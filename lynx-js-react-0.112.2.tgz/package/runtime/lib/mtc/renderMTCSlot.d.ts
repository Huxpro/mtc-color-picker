import type { VNode } from 'preact';
export declare function renderMTCSlot(btc: {
    $$typeof: string;
    i: number;
}): unknown;
export declare function renderFakeMTCSlot(jsxs: [VNode, {
    i: number;
}][]): VNode[];
