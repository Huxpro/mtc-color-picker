import type { VNode } from 'preact';
import type { SnapshotInstance } from '../snapshot.js';
export declare const mtcComponentVNodes: Map<string, [VNode, SnapshotInstance]>;
