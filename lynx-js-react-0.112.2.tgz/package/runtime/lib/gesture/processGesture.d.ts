import type { GestureKind } from './types.js';
export declare function processGesture(dom: FiberElement, gesture: GestureKind, oldGesture: GestureKind | undefined, isFirstScreen: boolean, gestureOptions?: {
    domSet: boolean;
}): void;
