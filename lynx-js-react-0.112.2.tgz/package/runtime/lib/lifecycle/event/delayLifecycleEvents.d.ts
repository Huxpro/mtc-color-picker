import type { LifecycleConstant } from '../../lifecycleConstant.js';
declare const delayedLifecycleEvents: [type: LifecycleConstant, data: unknown][];
declare function delayLifecycleEvent(type: LifecycleConstant, data: unknown): void;
export {};
