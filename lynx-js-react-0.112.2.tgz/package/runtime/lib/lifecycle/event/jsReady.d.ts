declare let isJSReady: boolean;
declare let jsReadyEventIdSwap: Record<string | number, number>;
declare function jsReady(): void;
declare function clearJSReadyEventIdSwap(): void;
declare function resetJSReady(): void;
export {};
