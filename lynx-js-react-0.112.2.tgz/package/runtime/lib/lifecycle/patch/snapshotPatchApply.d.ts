import type { SnapshotPatch } from './snapshotPatch.js';
/**
 * Applies a patch of snapshot operations to the main thread.
 * This is the counterpart to the patch generation in the background thread.
 * Each operation in the patch is processed sequentially to update the DOM.
 */
export declare function snapshotPatchApply(snapshotPatch: SnapshotPatch): void;
