import type { SnapshotPatch } from './snapshotPatch.js';
declare let globalFlushOptions: FlushOptions;
declare const globalCommitTaskMap: Map<number, () => void>;
declare let globalBackgroundSnapshotInstancesToRemove: number[];
/**
 * A single patch operation.
 */
interface Patch {
    id: number;
    snapshotPatch?: SnapshotPatch;
    workletRefInitValuePatch?: [id: number, value: unknown][];
}
/**
 * List of patches to be applied in a single update cycle with flush options.
 */
interface PatchList {
    patchList: Patch[];
    flushOptions?: FlushOptions;
}
/**
 * Configuration options for patch operations
 */
interface PatchOptions {
    pipelineOptions?: PipelineOptions;
    reloadVersion: number;
    isHydration?: boolean;
    flowIds?: number[];
}
/**
 * Allow to pass options to the patch operation
 */
export type GlobalPatchOptions = Omit<PatchOptions, 'reloadVersion'>;
export declare let globalPatchOptions: GlobalPatchOptions;
/**
 * Replaces Preact's default commit hook with our custom implementation
 */
declare function replaceCommitHook(): void;
/**
 * Prepares the patch update for transmission to the native layer
 */
declare function commitPatchUpdate(patchList: PatchList, patchOptions: GlobalPatchOptions): {
    data: string;
    patchOptions: PatchOptions;
};
/**
 * Generates a unique ID for commit tasks
 */
declare function genCommitTaskId(): number;
/**
 * Resets the commit task ID counter
 */
declare function clearCommitTaskId(): void;
export {};
