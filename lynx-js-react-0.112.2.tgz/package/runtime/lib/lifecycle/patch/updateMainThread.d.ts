declare function injectUpdateMainThread(): void;
export {};
