declare function reloadMainThread(data: unknown, options: UpdatePageOption): void;
declare function reloadBackground(updateData: Record<string, any>): void;
export { reloadBackground, reloadMainThread };
