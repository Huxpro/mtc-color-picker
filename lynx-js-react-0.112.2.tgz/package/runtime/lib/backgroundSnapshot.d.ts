import type { SnapshotPatch } from './lifecycle/patch/snapshotPatch.js';
import type { SerializedSnapshotInstance, Snapshot } from './snapshot.js';
export declare class BackgroundSnapshotInstance {
    type: string;
    constructor(type: string);
    __id: number;
    __values: any[] | undefined;
    __snapshot_def: Snapshot;
    __extraProps?: Record<string, unknown> | undefined;
    private __parent;
    private __firstChild;
    private __lastChild;
    private __previousSibling;
    private __nextSibling;
    private __removed_from_tree?;
    get parentNode(): BackgroundSnapshotInstance | null;
    get nextSibling(): BackgroundSnapshotInstance | null;
    contains(child: BackgroundSnapshotInstance): boolean;
    appendChild(child: BackgroundSnapshotInstance): void;
    insertBefore(node: BackgroundSnapshotInstance, beforeNode?: BackgroundSnapshotInstance): void;
    removeChild(node: BackgroundSnapshotInstance): void;
    tearDown(): void;
    get childNodes(): BackgroundSnapshotInstance[];
    setAttribute(key: string | number, value: unknown): void;
    private setAttributeImpl;
}
export declare function hydrate(before: SerializedSnapshotInstance, after: BackgroundSnapshotInstance): SnapshotPatch;
