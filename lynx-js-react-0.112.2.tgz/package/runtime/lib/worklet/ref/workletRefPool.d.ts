export type workletRefInitValuePatch = [id: number, value: unknown][];
