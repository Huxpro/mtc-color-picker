export declare function injectUpdateMTRefInitValue(): void;
export declare function sendMTRefInitValueToMainThread(): void;
