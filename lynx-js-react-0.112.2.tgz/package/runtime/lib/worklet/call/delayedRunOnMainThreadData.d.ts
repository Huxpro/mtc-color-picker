import type { RunWorkletCtxData } from '@lynx-js/react/worklet-runtime/bindings';
export declare let delayedRunOnMainThreadData: RunWorkletCtxData[];
export declare function takeDelayedRunOnMainThreadData(): typeof delayedRunOnMainThreadData;
