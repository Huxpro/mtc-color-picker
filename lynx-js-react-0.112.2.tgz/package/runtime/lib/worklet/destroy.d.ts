export declare const destroyTasks: (() => void)[];
export declare function destroyWorklet(): void;
