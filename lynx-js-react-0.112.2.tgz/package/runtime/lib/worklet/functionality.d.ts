declare function clearConfigCacheForTesting(): void;
export { isMtsEnabled, isRunOnBackgroundEnabled, clearConfigCacheForTesting };
