import type { ComponentClass } from 'preact';
export declare function isDirectOrDeepEqual(a: any, b: any): boolean;
export declare function isEmptyObject(obj?: object): obj is Record<string, never>;
export declare function isSdkVersionGt(major: number, minor: number): boolean;
export declare function pick<T extends object, K extends keyof T>(obj: T, keys: Iterable<K>): Pick<T, K>;
export declare function maybePromise<T>(value: unknown): value is Promise<T>;
export declare function getDisplayName(type: ComponentClass): string;
export declare function hook<T, K extends keyof T>(object: T, key: K, fn: Required<T>[K] extends (...args: infer P) => infer Q ? ((old?: T[K], ...args: P) => Q) : never): void;
