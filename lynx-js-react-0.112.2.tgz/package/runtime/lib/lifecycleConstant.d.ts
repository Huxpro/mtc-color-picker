export declare const enum LifecycleConstant {
    firstScreen = "rLynxFirstScreen",
    updateFromRoot = "updateFromRoot",
    globalEventFromLepus = "globalEventFromLepus",
    jsReady = "rLynxJSReady",
    patchUpdate = "rLynxChange",
    publishEvent = "rLynxPublishEvent"
}
export interface FirstScreenData {
    root: string;
    jsReadyEventIdSwap: Record<string | number, number>;
}
export declare const enum NativeUpdateDataType {
    UPDATE = 0,
    RESET = 1
}
