import { SnapshotInstance } from '../snapshot.js';
export declare function updateGesture(snapshot: SnapshotInstance, expIndex: number, oldValue: any, elementIndex: number, workletType: string): void;
