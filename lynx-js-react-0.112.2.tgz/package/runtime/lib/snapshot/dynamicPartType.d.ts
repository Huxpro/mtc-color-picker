/**
 * Types of dynamic parts that can be updated in a snapshot
 * These are determined at compile time through static analysis
 */
export declare const enum DynamicPartType {
    Attr = 0,// Regular attribute updates
    Spread = 1,// Spread operator in JSX
    Slot = 2,// Slot for component children
    Children = 3,// Regular children updates
    ListChildren = 4,// List/array children updates
    MultiChildren = 5
}
