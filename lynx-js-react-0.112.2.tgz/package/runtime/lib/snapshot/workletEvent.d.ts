import type { Worklet } from '@lynx-js/react/worklet-runtime/bindings';
import { SnapshotInstance } from '../snapshot.js';
declare function updateWorkletEvent(snapshot: SnapshotInstance, expIndex: number, oldValue: Worklet, elementIndex: number, workletType: string, eventType: string, eventName: string): void;
export { updateWorkletEvent };
