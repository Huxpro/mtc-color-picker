import type { SnapshotInstance } from '../snapshot.js';
import { RefProxy } from '../lifecycle/ref/delay.js';
type Ref = (((ref: RefProxy) => (() => void) | void) | {
    current: RefProxy | null;
}) & {
    _unmount?: (() => void) | void;
    __ref?: {
        value: number;
    };
};
declare function unref(snapshot: SnapshotInstance, recursive: boolean): void;
declare function applyRef(ref: Ref, value: null | [snapshotInstanceId: number, expIndex: number]): void;
declare function updateRef(snapshot: SnapshotInstance, expIndex: number, oldValue: string | {
    current: any | null;
} | ((ref: any) => void) | null, elementIndex: number): void;
declare function transformRef(ref: unknown): Ref | null | undefined;
declare function applyQueuedRefs(): void;
declare function queueRefAttrUpdate(oldRef: Ref | null | undefined, newRef: Ref | null | undefined, snapshotInstanceId: number, expIndex: number): void;
declare function clearQueuedRefs(): void;
export {};
