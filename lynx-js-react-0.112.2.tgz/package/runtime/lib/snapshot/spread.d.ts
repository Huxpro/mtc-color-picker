import type { BackgroundSnapshotInstance } from '../backgroundSnapshot.js';
import { SnapshotInstance } from '../snapshot.js';
declare function updateSpread(snapshot: SnapshotInstance, index: number, oldValue: Record<string, unknown> | undefined | null, elementIndex: number): void;
declare function transformSpread(snapshot: BackgroundSnapshotInstance | SnapshotInstance, index: number, spread: Record<string, unknown>): Record<string, unknown>;
export { transformSpread, updateSpread };
