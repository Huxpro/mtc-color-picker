import type { RefCallback, RefObject } from 'preact';
import type { Element, Worklet, WorkletRefImpl } from '@lynx-js/react/worklet-runtime/bindings';
import type { SnapshotInstance } from '../snapshot.js';
type Ref = WorkletRefImpl<Element> | Worklet | RefObject<Element> | RefCallback<Element>;
export declare function applyRefQueue(): void;
export declare function addToRefQueue(worklet: Ref, element: Element): void;
export declare function workletUnRef(value: Ref): void;
export declare function updateWorkletRef(snapshot: SnapshotInstance, expIndex: number, oldValue: WorkletRefImpl<Element> | Worklet | null | undefined, elementIndex: number, _workletType: string): void;
export {};
