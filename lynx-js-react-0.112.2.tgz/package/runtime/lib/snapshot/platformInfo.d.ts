import { SnapshotInstance } from '../snapshot.js';
declare const platformInfoAttributes: Set<string>;
export interface PlatformInfo {
    'reuse-identifier'?: string;
    'full-span'?: boolean;
    'item-key'?: string;
    'sticky-top'?: boolean;
    'sticky-bottom'?: boolean;
    'estimated-height'?: number;
    'estimated-height-px'?: number;
    'estimated-main-axis-size-px'?: number;
    'recyclable'?: boolean;
}
declare function updateListItemPlatformInfo(ctx: SnapshotInstance, index: number, oldValue: any, elementIndex: number): void;
export { updateListItemPlatformInfo, platformInfoAttributes };
