import type { SnapshotInstance } from '../snapshot.js';
export declare function snapshotCreateList(pageId: number, _ctx: SnapshotInstance, _expIndex: number): FiberElement;
export declare function snapshotDestroyList(si: SnapshotInstance): void;
