export declare function describeInvalidValue(value: unknown): string;
