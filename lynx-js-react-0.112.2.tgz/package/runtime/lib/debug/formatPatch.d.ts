import type { SnapshotPatch } from '../lifecycle/patch/snapshotPatch.js';
export declare function prettyFormatSnapshotPatch(snapshotPatch: SnapshotPatch | undefined): unknown[];
