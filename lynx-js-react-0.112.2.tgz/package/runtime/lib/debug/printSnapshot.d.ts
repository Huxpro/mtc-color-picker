import type { BackgroundSnapshotInstance } from '../backgroundSnapshot.js';
import { SnapshotInstance } from '../snapshot.js';
export declare function printSnapshotInstance(instance: BackgroundSnapshotInstance | SnapshotInstance, log?: (...data: any[]) => void): void;
