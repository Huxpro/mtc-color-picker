export declare function initProfileHook(): void;
