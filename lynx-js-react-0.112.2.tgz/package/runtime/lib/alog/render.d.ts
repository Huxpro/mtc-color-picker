export declare function initRenderAlog(): void;
