import { Component } from 'preact';
import type { ReactNode } from 'react';
export declare function wrapWithLynxComponent(jsxSnapshot: (c: ReactNode, spread?: Record<string, any>) => ReactNode, jsxComponent: any): ReactNode;
export declare class ComponentFromReactRuntime extends Component {
}
