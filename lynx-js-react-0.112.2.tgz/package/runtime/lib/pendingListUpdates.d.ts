import type { ListUpdateInfo } from './listUpdateInfo.js';
export declare const __pendingListUpdates: {
    values: Record<number, ListUpdateInfo> | null;
    clear(): void;
    flush(): void;
    runWithoutUpdates(cb: () => void): void;
};
