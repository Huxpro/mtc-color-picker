import type { SnapshotInstance } from './snapshot.js';
export interface ListUpdateInfo {
    flush(): void;
    onInsertBefore(newNode: SnapshotInstance, existingNode?: SnapshotInstance): void;
    onRemoveChild(child: SnapshotInstance): void;
    onSetAttribute(child: SnapshotInstance, attr: any, oldAttr: any): void;
}
interface InsertAction {
    position: number;
    type: string;
}
interface UpdateAction {
    from: number;
    to: number;
    type: string;
    flush: boolean;
}
interface ListOperations {
    insertAction: InsertAction[];
    removeAction: number[];
    updateAction: UpdateAction[];
}
export declare class ListUpdateInfoRecording implements ListUpdateInfo {
    private list;
    constructor(list: SnapshotInstance);
    flush(): void;
    private oldChildNodes;
    private removeChild;
    private insertBefore;
    private appendChild;
    private platformInfoUpdate;
    onInsertBefore(newNode: SnapshotInstance, existingNode?: SnapshotInstance): void;
    onRemoveChild(child: SnapshotInstance): void;
    onSetAttribute(child: SnapshotInstance, attr: any, _oldAttr: any): void;
    private __toAttribute;
    toJSON(): [ListOperations];
}
export {};
