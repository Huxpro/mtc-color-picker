declare function injectCalledByNative(): void;
export {};
