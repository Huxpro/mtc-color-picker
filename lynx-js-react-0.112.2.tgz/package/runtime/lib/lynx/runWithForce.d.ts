export declare function runWithForce(cb: () => void): void;
