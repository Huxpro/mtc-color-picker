import type { FunctionComponent, VNode } from 'preact';
export declare const Suspense: FunctionComponent<{
    children: VNode | VNode[];
    fallback: VNode;
}>;
