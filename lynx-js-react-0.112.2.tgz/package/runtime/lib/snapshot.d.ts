import type { Worklet, WorkletRefImpl } from '@lynx-js/react/worklet-runtime/bindings';
import type { BackgroundSnapshotInstance } from './backgroundSnapshot.js';
import { DynamicPartType } from './snapshot/dynamicPartType.js';
import type { PlatformInfo } from './snapshot/platformInfo.js';
/**
 * A snapshot definition that contains all the information needed to create and update elements
 * This is generated at compile time through static analysis of the JSX
 */
export interface Snapshot {
    create: null | ((ctx: SnapshotInstance) => FiberElement[]);
    update: null | ((ctx: SnapshotInstance, index: number, oldValue: any) => void)[];
    slot: [DynamicPartType, number][];
    isListHolder?: boolean;
    cssId?: number | undefined;
    entryName?: string | undefined;
    refAndSpreadIndexes?: number[] | null;
}
export declare let __page: FiberElement;
export declare let __pageId: number;
export declare function setupPage(page: FiberElement): void;
export declare function clearPage(): void;
export declare const __DynamicPartChildren_0: [DynamicPartType, number][];
export declare const snapshotManager: {
    values: Map<string, Snapshot>;
};
export declare const snapshotInstanceManager: {
    nextId: number;
    values: Map<number, SnapshotInstance>;
    clear(): void;
};
export declare const backgroundSnapshotInstanceManager: {
    nextId: number;
    values: Map<number, BackgroundSnapshotInstance>;
    clear(): void;
    updateId(id: number, newId: number): void;
    getValueBySign(str: string): unknown;
};
export declare function entryUniqID(uniqID: string, entryName?: string): string;
export declare function createSnapshot(uniqID: string, create: Snapshot['create'] | null, update: Snapshot['update'] | null, slot: Snapshot['slot'], cssId: number | undefined, entryName: string | undefined, refAndSpreadIndexes: number[] | null): string;
export interface WithChildren {
    childNodes: WithChildren[];
}
export declare function traverseSnapshotInstance<I extends WithChildren>(si: I, callback: (si: I) => void): void;
export interface SerializedSnapshotInstance {
    id: number;
    type: string;
    values?: any[] | undefined;
    extraProps?: Record<string, unknown> | undefined;
    children?: SerializedSnapshotInstance[] | undefined;
}
/**
 * The runtime instance of a {@link Snapshot} on the main thread that manages
 * the actual elements and handles updates to dynamic parts.
 *
 * This class is designed to be compatible with Preact's {@link ContainerNode}
 * interface for Preact's renderer to operate upon.
 */
export declare class SnapshotInstance {
    type: string;
    __id: number;
    __snapshot_def: Snapshot;
    __elements?: FiberElement[] | undefined;
    __element_root?: FiberElement | undefined;
    __values?: unknown[] | undefined;
    __current_slot_index: number;
    __worklet_ref_set?: Set<WorkletRefImpl<any> | Worklet>;
    __listItemPlatformInfo?: PlatformInfo;
    __extraProps?: Record<string, unknown> | undefined;
    __onDestroy?: () => void;
    constructor(type: string, id?: number);
    ensureElements(): void;
    unRenderElements(): void;
    takeElements(): SnapshotInstance;
    tearDown(): void;
    private __parent;
    private __firstChild;
    private __lastChild;
    private __previousSibling;
    private __nextSibling;
    get parentNode(): SnapshotInstance | null;
    get nextSibling(): SnapshotInstance | null;
    contains(child: SnapshotInstance): boolean;
    get childNodes(): SnapshotInstance[];
    __insertBefore(node: SnapshotInstance, beforeNode?: SnapshotInstance): void;
    __removeChild(node: SnapshotInstance): void;
    insertBefore(newNode: SnapshotInstance, existingNode?: SnapshotInstance): void;
    removeChild(child: SnapshotInstance, options?: {
        keepSubTree: boolean;
    }): void;
    setAttribute(key: string | number, value: any): void;
    toJSON(): Omit<SerializedSnapshotInstance, 'children'> & {
        children: SnapshotInstance[] | undefined;
    };
    callUpdateIfNotDirectOrDeepEqual(index: number, oldValue: any, newValue: any): void;
}
