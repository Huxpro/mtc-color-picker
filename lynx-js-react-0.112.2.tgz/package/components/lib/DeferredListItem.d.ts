import type { FC, ReactNode } from 'react';
export interface DeferredListItemProps {
    defer?: boolean | {
        unmountRecycled?: boolean;
    };
    renderListItem: (children: ReactNode | undefined) => JSX.Element;
    renderChildren: () => ReactNode;
}
export declare const DeferredListItem: FC<DeferredListItemProps>;
