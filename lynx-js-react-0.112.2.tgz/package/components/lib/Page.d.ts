import type { ForwardRefExoticComponent, PropsWithChildren, RefAttributes } from 'react';
declare const Page: ForwardRefExoticComponent<Omit<PropsWithChildren, 'ref'> & RefAttributes<unknown>>;
export { Page };
